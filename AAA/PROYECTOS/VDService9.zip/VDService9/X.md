1. Componente header incluido
2. Base de datos incluida
- La base de datos es un espacio privado solo para el administrador, donde podrá ver:
   - Las visitas a su página(pueden ser resultados mensuales)
   - Tabla con clientes
        1. Particulares
        2. Empresas
   - Tabla con distribuidores
   - Contaduría (en proceso)
   - Tabla de trabajadores
3. Login y Logout funcionales
