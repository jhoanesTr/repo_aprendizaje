<!DOCTYPE html>
<html lang="es_ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto</title>
    <link rel="stylesheet" href="src/style.css">
    <link rel="stylesheet" href="src/css.css">
</head>
<body>
<?php include "components/header.php" ?>
    <main class="bg-img">

        <div class="container px-5 pt-4 d-flex">
            <div class="container-fluid col-xl-8 col-lg-8">
                <form action="" method="post">
                    <h2 class="text-secondary">Ayudanos a ayudarte ;)</h2>

                            <!--Fila 1-->
        <!--VERIFICAR--><div class="row row-cols-xl-3 row-cols-xs-2">
                                <!--Nombre-->
                            <div class="col-xl-2 col-4">
                                <label for="Nombre" class="form-label">Nombre:</label>
                                <input type="text" id="Nombre" class="form-control mb-2" required>
                            </div>

                                <!--Correo-->
                            <div class="col-xl-5 col-8">
                                <label for="Correo" class="form-label">Correo:</label>
                                <input type="email" id="Correo" class="form-control mb-2" required>
                            </div>

                                <!--Ciudad-->
                            <div class="col-xl-3 col-7">
                                <label for="Ciudad" class="form-label">Ciudad:</label>
                                <select name="" id="Ciudad" class="form-select mb-2" required>
                                    <option value="" disabled>Escoge</option>
                                    <option value="">...</option>
                                    <option value="">Pontevedra</option>
                                    <option value="">Vigo</option>
                                    <option value="">A Coruña</option>
                                    <option value="">Santiago de Compostela</option>
                                </select>
                            </div>

                                <!--CP-->
                            <div class="col-xl-2 col-3">
                                <label for="CP" class="form-label">CP:</label>
                                <input type="text" id="CP" class="form-control mb-2" required>
                            </div>

                                <!--Dirección-->
                            <div class="col-xl-5">
                                <label for="Direccion" class="form-label">Dirección:</label>
                                <input type="text" id="Direccion" class="form-control mb-2">
                            </div>

                                <!--Motivo-->
                            <div class="col-xl-3 col-6">
                                <label for="Motivo" class="form-label">Motivo:</label>
                                <select name="" id="" class="form-select mb-2" required>
                                    <option value="" disabled>Escoge:</option>
                                    <option value="">...</option>
                                    <option value="">Averia</option>
                                    <option value="">Renovación</option>
                                    <option value="">Instalación nueva</option>
                                </select>
                            </div>

                                <!--Teléfono-->
                            <div class="col-xl-3 col-5">
                                <label for="Telefono" class="form-label">Teléfono:</label>
                                <input type="tel" id="Telefono" class="form-control mb-2" required>
                            </div>
                        </div>
                            <button type="submit" class="btn-secondary mt-2 rounded-3 border-0">Enviar</button>
                </form>
            </div>

            <!--div oculto para Teléfonos-->
            <div class="container-fluid d-none d-xl-block d-lg-block">
                <div class="container-fluid pt-1">
                    <h2 class="text-primary">Contáctenos!</h2>
                            <!--Teléfono-->
                        <div></div>
                            <!--WhatsApp-->
                        <div></div>
                            <!--Telegram-->
                        <div></div>
                </div>
            </div>

        </div>
    </main>

    
    
<?php include "components/footer.php" ?>
<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>