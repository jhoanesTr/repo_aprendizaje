npm init -y
npm install bootstrap
npm install @popperjs/core
--------------------------
# Configuracion VSCode
Auto Rename Tag
Code spell Checker
Colorize
GitHub
HTML CSS Support
HTML End Tag Labels
HTML Snippets
IntelliSense for CSS class names in HTML
Live Sass Compiler
PHP Debug
PHP Extension Pack
PHP Intelphense
PHP IntelliSense
PHP Namespace Resolver
Spanish-Code Spell Checker
Twig
## settings.json
{
    "workbench.colorTheme": "Visual Studio Dark",
    "security.workspace.trust.untrustedFiles": "open",
    "liveServer.settings.donotShowInfoMsg": true,
    "liveServer.settings.donotVerifyTags": true,
    "bracket-pair-colorizer-2.showBracketsInRuler": true,
    "git.enableSmartCommit": true,
    "workbench.iconTheme": "material-icon-theme",
    "git.autofetch": true,
    "bracket-pair-colorizer-2.depreciation-notice": false,
    "explorer.confirmDelete": false,
    "explorer.confirmDragAndDrop": false,
    "diffEditor.ignoreTrimWhitespace": false,
    "better-comments.multilineComments": true,
//indica si linter se ejecuta al guardar o al escribir
    "php.validate.run": "onSave",

//PHP Intellisense
"php.validate.enable": true,
"php.executablePath": "C:/laragon/bin/php/php-7.4.27-nts-Win32-vc15-x64/php.exe",
"php.validate.executablePath": "C:/laragon/bin/php/php-7.4.27-nts-Win32-vc15-x64/php.exe",

//Sass copilador
    "liveSassCompile.settings.formats": [
        {
            "format": "compressed",
            "extensionName": ".css",
            "savePath": "/src"
        }
    ],

"cSpell.language": "en,es",
"cSpell.userWords": [
    "popperjs"
],
}