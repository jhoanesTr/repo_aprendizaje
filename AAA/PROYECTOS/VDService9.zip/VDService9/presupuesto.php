<!DOCTYPE html>
<html lang="es_ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Presupuesto</title>
    <link rel="stylesheet" href="src/style.css">
    <link rel="stylesheet" href="src/css.css">

</head>
<body>
<?php include "components/header.php" ?>

<main class="bg-img">
        <div class="container px-5 pt-4">
        </div>
    </main>
    
<?php include "components/footer.php" ?>
<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>