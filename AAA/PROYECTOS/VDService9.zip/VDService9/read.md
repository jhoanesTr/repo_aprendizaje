aling-items= alinea verticalmente
justify-content= alinea horizontalmente
# Info code
color: #FFC107; Amarillo
 

