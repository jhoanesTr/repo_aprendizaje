<!DOCTYPE html>
<html lang="es_ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto</title>
    <link rel="stylesheet" href="src/style.css">
    <link rel="stylesheet" href="src/css.css">
</head>
<body>
<?php include "components/header.php" ?>

    <main class="bg-img">
        <div class="container-fluid px-5 pt-4">
            <form action="" method="post">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Et voluptate pariatur, voluptatibus corrupti rerum laudantium hic aut, repudiandae, quos recusandae repellendus delectus earum beatae. Ducimus saepe dolore debitis tempora odit?
            </form>
        </div>
    </main>
    
    <?php include "components/footer.php" ?>
    <script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>