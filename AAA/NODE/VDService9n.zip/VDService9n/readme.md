npm init -y
npm install bootstrap
npm install @popperjs/core