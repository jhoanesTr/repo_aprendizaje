<?php if (isset($component)) { $__componentOriginal9d59c24e68be4885608a53659467958995cdebbb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inc\Navheader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inc.navheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Inc\Navheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d59c24e68be4885608a53659467958995cdebbb)): ?>
<?php $component = $__componentOriginal9d59c24e68be4885608a53659467958995cdebbb; ?>
<?php unset($__componentOriginal9d59c24e68be4885608a53659467958995cdebbb); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\php8\VDService9\resources\views/welcome.blade.php ENDPATH**/ ?>