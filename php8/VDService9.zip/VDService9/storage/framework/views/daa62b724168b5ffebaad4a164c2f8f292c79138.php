<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!--Espacio para título de página-->
    <title>VDService9:<?php echo $__env->yieldContent('title_page'); ?></title>

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/css.css')); ?>">
</head>
<body>

<!--Header-->
<?php if (isset($component)) { $__componentOriginal9d59c24e68be4885608a53659467958995cdebbb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inc\Navheader::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inc.navheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Inc\Navheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d59c24e68be4885608a53659467958995cdebbb)): ?>
<?php $component = $__componentOriginal9d59c24e68be4885608a53659467958995cdebbb; ?>
<?php unset($__componentOriginal9d59c24e68be4885608a53659467958995cdebbb); ?>
<?php endif; ?>

<main class="pb-5">
    <div class="px-xxl-5 ps-xl-5 ps-lg-5 ps-3 pt-xxl-4 pt-xl-4 pt-lg-4 pt-3">
        <?php echo e($slot); ?>

    </div>
</main>

<!--Footer-->
<?php if (isset($component)) { $__componentOriginalb0cd76f5a5f90c1965c85d486eacc4e83f957ba9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inc\Footer::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inc.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Inc\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb0cd76f5a5f90c1965c85d486eacc4e83f957ba9)): ?>
<?php $component = $__componentOriginalb0cd76f5a5f90c1965c85d486eacc4e83f957ba9; ?>
<?php unset($__componentOriginalb0cd76f5a5f90c1965c85d486eacc4e83f957ba9); ?>
<?php endif; ?>
<!-- Scripts -->
<script src="<?php echo e(asset('bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\php8\VDService9\resources\views/components/layout.blade.php ENDPATH**/ ?>