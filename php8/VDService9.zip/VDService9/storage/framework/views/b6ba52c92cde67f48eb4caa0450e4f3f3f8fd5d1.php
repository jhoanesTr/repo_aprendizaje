<footer class="fw-bold">
    <div class="text-center pt-4 pb-4 bg-secondary text-white">
        © 2022 Copyright:
        <a class="link-primary text-decoration-none" href="https://www.linkedin.com/in/jhoanesv/">Jhoanes Villarroel</a>
    </div>
</footer>

<?php /**PATH C:\laragon\www\php8\VDService9\resources\views/components/inc/footer.blade.php ENDPATH**/ ?>