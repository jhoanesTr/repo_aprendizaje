<header class="bg-secondary">
    <nav class="navbar navbar-expand-xxl navbar-expand-xl navbar-expand-lg navbar-expand-md p-3">
        <div class="container-fluid me-xxl-3 me-xl-3 me-lg-3 me-0">
            <!--Brand-->
            <a href="" class="navbar-brand">
                <span class="h3 text-primary">VDService9</span>
            </a>

            <!--Boton Menu-->
            <button class="navbar-toggler text-primary" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"></path>
                </svg>
            </button>

            <!--Contenido Menu-->
            <div class="collapse navbar-collapse flex-row-reverse" id="navmenu">
                <ul class="navbar-nav">
                    <li class="nav-item flex-row-reverse d-flex"><a href="<?php echo e(route('home')); ?>" class="nav-link active" aria-current="page">Home</a></li>
                    <li class="nav-item flex-row-reverse d-flex"><a href="<?php echo e(route('presupuesto.index')); ?>" class="nav-link">Presupuesto</a></li>
                    <li class="nav-item flex-row-reverse d-flex"><a href="<?php echo e(route('contacto.index')); ?>" class="nav-link">Contacto</a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\laragon\www\php8\VDService9\resources\views/components/inc/navheader.blade.php ENDPATH**/ ?>