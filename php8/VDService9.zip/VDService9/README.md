#Git
```shell
git init
git add .
git commit -m ""
git branch -M main
git remote add origin https://github.com/jhoanesTr/Laravel9_VDService9.git
git push -u origin main

```
