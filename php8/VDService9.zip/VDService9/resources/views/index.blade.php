<x-layout>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Commodi, corporis doloremque iusto labore laborum libero maxime necessitatibus pariatur, praesentium quae recusandae repellendus soluta ullam, vel vero! Adipisci assumenda dolorum ipsam?
</x-layout>
